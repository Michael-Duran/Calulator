//
//  main.m
//  Calulator
//
//  Created by Michael on 3/4/14.
//  Copyright (c) 2014 Macbook Air. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "MDAppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([MDAppDelegate class]));
    }
}
